# 3. POST /api/transactions/search
def search_transactions(request):

#4. GET /api/transactions/types